# Malnutrition-Detection-Project
This repository is about my Final Year project in Computer Science where I and my team create Machine learning models using both image data and numeric data that is integrated into a mobile based Application so that parents can input details  of their children into the application and they can know whether their child is malnourished or not. A Person has to first input the image of the child and the image processing model runs, if it displays Healthy, then no other further action is required, but if it displays Malnourished, then the person must put in the details of the child such as Age, Gender, Height and Weight to know if the child is Stunted, Wasted, Overwight or underweight.

This app is just intended to be an aid to parents and guardians to check the health status of the child and not a substitute for professional advice. 

This can help in early detection of manutrition cases in infants and can then be treated early enough and more efficiently
.
The main file with the latest and complete information is the "Oversampling file".
You can just run it on jupyter note book .

